# puRduePsych
 A package consolidating analyses for Purdue University's required Statistics courses in Psychological Sciences

## Installation
To install, run the following lines of code in your R-Studio Console:

```
install.packages("devtools")
devtools::install_github("daniboid/puRduePsych")
```

